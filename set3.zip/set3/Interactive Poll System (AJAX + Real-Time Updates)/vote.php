<?php

$vote = $_POST['vote'];

echo "

<h3>

Vote Submitted for $vote

</h3>

";

?>