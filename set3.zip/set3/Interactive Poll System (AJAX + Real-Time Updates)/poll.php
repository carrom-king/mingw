<?php

echo "

<div class='option'>

Python

<button

class='vote'

data-option='Python'>

Vote

</button>

</div>

<div class='option'>

Java

<button

class='vote'

data-option='Java'>

Vote

</button>

</div>

<div class='option'>

PHP

<button

class='vote'

data-option='PHP'>

Vote

</button>

</div>

";

?>