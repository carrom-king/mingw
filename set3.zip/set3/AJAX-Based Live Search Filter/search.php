<?php

$products = [

    "Mobile",
    "Laptop",
    "Headphones",
    "Keyboard",
    "Mouse",
    "Monitor"
];

$search = strtolower($_GET['search']);

$found = false;

foreach($products as $product){

    if(strpos(strtolower($product),$search) !== false){

        echo "<div class='item'>$product</div>";

        $found = true;
    }
}

if(!$found){

    echo "<div class='no-result'>
    No results found
    </div>";
}

?>