<?php

$users = ["admin","john","ralston"];

$username = $_POST['username'];

if(in_array($username,$users)){

    echo "<span style='color:red'>
    Username Taken
    </span>";
}

else{

    echo "<span style='color:green'>
    Username Available
    </span>";
}

?>