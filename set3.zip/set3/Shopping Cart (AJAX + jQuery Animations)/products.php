<?php

echo "

<div class='product'>

Laptop - ₹50000

<button

class='add'

data-name='Laptop'

data-price='50000'>

Add

</button>

</div>

<div class='product'>

Mobile - ₹20000

<button

class='add'

data-name='Mobile'

data-price='20000'>

Add

</button>

</div>

<div class='product'>

Headphones - ₹3000

<button

class='add'

data-name='Headphones'

data-price='3000'>

Add

</button>

</div>

";

?>