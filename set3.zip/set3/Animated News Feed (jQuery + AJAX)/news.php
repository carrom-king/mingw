<?php

$news = [

    "AI is transforming the world",

    "New smartphone launched today",

    "India wins cricket match",

    "Web development demand rising"
];

foreach($news as $item){

    echo "

    <div class='news'>

    $item

    </div>

    ";
}

?>