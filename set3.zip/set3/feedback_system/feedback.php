<?php
$conn = new mysqli("localhost", "root", "", "feedback_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $email = $message = "";
$errors = [];
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    // Validation
    if (empty($name)) {
        $errors[] = "Name is required";
    }

    if (empty($email)) {
        $errors[] = "Email is required";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid Email Format";
    }

    if (empty($message)) {
        $errors[] = "Feedback message is required";
    } elseif (strlen($message) < 20) {
        $errors[] = "Feedback must be at least 20 characters";
    }

    // Insert Data
    if (empty($errors)) {

        $stmt = $conn->prepare("INSERT INTO feedback(name, email, message) VALUES (?, ?, ?)");

        $stmt->bind_param("sss", $name, $email, $message);

        if ($stmt->execute()) {
            $success = "Feedback Submitted Successfully";
        } else {
            $errors[] = "Error submitting feedback";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Online Feedback Form</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
        }

        .container {
            width: 500px;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            background: blue;
            color: white;
            border: none;
        }

        .error {
            color: red;
        }

        .success {
            color: green;
        }
    </style>
</head>
<body>

<div class="container">

<h2>College Feedback Form</h2>

<?php
if (!empty($errors)) {
    echo "<div class='error'>";
    foreach($errors as $error) {
        echo "<p>$error</p>";
    }
    echo "</div>";
}

if ($success != "") {
    echo "<p class='success'>$success</p>";
}
?>

<form method="POST">

<input type="text" name="name" placeholder="Enter Name">

<input type="text" name="email" placeholder="Enter Email">

<textarea name="message" rows="5" placeholder="Enter Feedback"></textarea>

<button type="submit">Submit Feedback</button>

</form>

</div>

</body>
</html>