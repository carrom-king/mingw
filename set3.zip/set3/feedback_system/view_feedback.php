<?php
$conn = new mysqli("localhost", "root", "", "feedback_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Pagination
$limit = 5;

$page = isset($_GET['page']) ? $_GET['page'] : 1;

$start = ($page - 1) * $limit;

// Fetch feedback
$result = $conn->query("SELECT * FROM feedback ORDER BY id DESC LIMIT $start, $limit");

// Count total records
$total_result = $conn->query("SELECT COUNT(*) AS total FROM feedback");

$total_row = $total_result->fetch_assoc();

$total_records = $total_row['total'];

$total_pages = ceil($total_records / $limit);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Feedback</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
        }

        .container {
            width: 900px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        .pagination a {
            padding: 8px 12px;
            border: 1px solid black;
            margin-right: 5px;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="container">

<h2>Student Feedback Entries</h2>

<table>

<tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Feedback</th>
    <th>Date</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['email']; ?></td>
    <td><?php echo $row['message']; ?></td>
    <td><?php echo $row['created_at']; ?></td>
</tr>

<?php } ?>

</table>

<br>

<div class="pagination">

<?php for($i=1; $i<=$total_pages; $i++) { ?>

<a href="view_feedback.php?page=<?php echo $i; ?>">
    <?php echo $i; ?>
</a>

<?php } ?>

</div>

</div>

</body>
</html>