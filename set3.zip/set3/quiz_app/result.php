<?php
$conn = new mysqli("localhost", "root", "", "online_quiz");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$score = 0;

if (isset($_POST['answer'])) {

    foreach ($_POST['answer'] as $question_id => $selected_answer) {

        // Store answer
        $stmt = $conn->prepare("INSERT INTO user_answers(question_id, selected_answer) VALUES (?, ?)");

        $stmt->bind_param("is", $question_id, $selected_answer);

        $stmt->execute();

        // Check correct answer
        $result = $conn->query("SELECT correct_answer FROM questions WHERE id=$question_id");

        $row = $result->fetch_assoc();

        if ($selected_answer == $row['correct_answer']) {
            $score++;
        }
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Quiz Result</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
            text-align: center;
            margin-top: 100px;
        }

        .result {
            background: white;
            display: inline-block;
            padding: 30px;
            border-radius: 10px;
        }
    </style>
</head>
<body>

<div class="result">

    <h1>Your Score: <?php echo $score; ?></h1>

    <a href="quiz.php">Take Quiz Again</a>

</div>

</body>
</html>