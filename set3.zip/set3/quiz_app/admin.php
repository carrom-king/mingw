<?php
$conn = new mysqli("localhost", "root", "", "online_quiz");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $question = trim($_POST['question']);
    $option1 = trim($_POST['option1']);
    $option2 = trim($_POST['option2']);
    $option3 = trim($_POST['option3']);
    $correct_answer = trim($_POST['correct_answer']);

    // Validation
    if (
        empty($question) ||
        empty($option1) ||
        empty($option2) ||
        empty($option3) ||
        empty($correct_answer)
    ) {
        $message = "All fields are required";
    } else {

        $stmt = $conn->prepare("INSERT INTO questions(question, option1, option2, option3, correct_answer) VALUES (?, ?, ?, ?, ?)");

        $stmt->bind_param("sssss", $question, $option1, $option2, $option3, $correct_answer);

        if ($stmt->execute()) {
            $message = "Question Added Successfully";
        } else {
            $message = "Error Adding Question";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Admin Panel</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
        }

        .container {
            width: 500px;
            margin: 40px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        input, textarea {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
        }

        button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
            background: green;
            color: white;
            border: none;
        }

        .message {
            color: blue;
        }
    </style>
</head>
<body>

<div class="container">

    <h2>Add Quiz Question</h2>

    <p class="message"><?php echo $message; ?></p>

    <form method="POST">

        <textarea name="question" placeholder="Enter Question"></textarea>

        <input type="text" name="option1" placeholder="Option 1">

        <input type="text" name="option2" placeholder="Option 2">

        <input type="text" name="option3" placeholder="Option 3">

        <input type="text" name="correct_answer" placeholder="Correct Answer">

        <button type="submit">Add Question</button>

    </form>

</div>

</body>
</html>