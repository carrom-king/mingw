<?php
$conn = new mysqli("localhost", "root", "", "attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$where = "";

if (isset($_GET['employee_id']) && $_GET['employee_id'] != "") {
    $employee_id = $_GET['employee_id'];
    $where .= " AND attendance.employee_id='$employee_id'";
}

if (isset($_GET['date']) && $_GET['date'] != "") {
    $date = $_GET['date'];
    $where .= " AND attendance.attendance_date='$date'";
}

$query = "
SELECT attendance.*, employees.name
FROM attendance
JOIN employees ON attendance.employee_id = employees.id
WHERE 1=1 $where
ORDER BY attendance.attendance_date DESC
";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Attendance Report</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
        }

        .container {
            width: 800px;
            margin: 30px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        table, th, td {
            border: 1px solid black;
        }

        th, td {
            padding: 10px;
            text-align: center;
        }

        input, select, button {
            padding: 8px;
            margin-right: 10px;
        }
    </style>
</head>
<body>

<div class="container">

<h2>Attendance Report</h2>

<form method="GET">

<select name="employee_id">

<option value="">All Employees</option>

<?php
$employees = $conn->query("SELECT * FROM employees");

while($emp = $employees->fetch_assoc()) {
?>

<option value="<?php echo $emp['id']; ?>">
    <?php echo $emp['name']; ?>
</option>

<?php } ?>

</select>

<input type="date" name="date">

<button type="submit">Filter</button>

</form>

<table>

<tr>
    <th>ID</th>
    <th>Employee Name</th>
    <th>Date</th>
    <th>Status</th>
</tr>

<?php while($row = $result->fetch_assoc()) { ?>

<tr>
    <td><?php echo $row['id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['attendance_date']; ?></td>
    <td><?php echo $row['status']; ?></td>
</tr>

<?php } ?>

</table>

</div>

</body>
</html>