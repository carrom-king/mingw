<?php
$conn = new mysqli("localhost", "root", "", "attendance_system");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $employee_id = $_POST['employee_id'];
    $status = $_POST['status'];
    $date = date("Y-m-d");

    // Check duplicate attendance
    $check = $conn->prepare("SELECT * FROM attendance WHERE employee_id=? AND attendance_date=?");

    $check->bind_param("is", $employee_id, $date);

    $check->execute();

    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $message = "Attendance already marked for today";
    } else {

        $stmt = $conn->prepare("INSERT INTO attendance(employee_id, attendance_date, status) VALUES (?, ?, ?)");

        $stmt->bind_param("iss", $employee_id, $date, $status);

        if ($stmt->execute()) {
            $message = "Attendance Marked Successfully";
        } else {
            $message = "Error";
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Employee Attendance</title>

    <style>
        body {
            font-family: Arial;
            background: #f2f2f2;
        }

        .container {
            width: 400px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
        }

        select, button {
            width: 100%;
            padding: 10px;
            margin-top: 15px;
        }

        .message {
            color: blue;
        }
    </style>
</head>
<body>

<div class="container">

<h2>Mark Attendance</h2>

<p class="message"><?php echo $message; ?></p>

<form method="POST">

<select name="employee_id" required>

<option value="">Select Employee</option>

<?php
$result = $conn->query("SELECT * FROM employees");

while($row = $result->fetch_assoc()) {
?>

<option value="<?php echo $row['id']; ?>">
    <?php echo $row['name']; ?>
</option>

<?php } ?>

</select>

<select name="status" required>
    <option value="">Select Status</option>
    <option value="Present">Present</option>
    <option value="Absent">Absent</option>
</select>

<button type="submit">Submit Attendance</button>

</form>

</div>

</body>
</html>