<!DOCTYPE html>
<html>
<head>
    <title>Welcome</title>
</head>
<body>

<h1>
    Welcome,
    <?php
    echo htmlspecialchars($_GET['name']);
    ?>
</h1>

<p>Registration Successful!</p>

</body>
</html>