<?php

echo "

<div class='comment' style='display:block'>
Nice Website
</div>

<div class='comment' style='display:block'>
Great Content
</div>

";

?>