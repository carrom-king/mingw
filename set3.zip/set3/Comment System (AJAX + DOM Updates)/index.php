<!DOCTYPE html>
<html>

<head>

    <title>Comment System</title>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <style>

        body{
            font-family: Arial;
        }

        .comment{

            background: lightgray;

            margin-top: 10px;

            padding: 10px;

            display: none;
        }

        .error{
            color: red;
        }

    </style>

</head>

<body>

<h2>Comment System</h2>

<textarea id="msg"></textarea>

<br><br>

<button id="btn">
    Post Comment
</button>

<p class="error"></p>

<div id="comments"></div>

<script>

$(document).ready(function(){

    // Load Old Comments

    $.get("comments.php",function(data){

        $("#comments").html(data);
    });

    // Add Comment

    $("#btn").click(function(){

        let comment = $("#msg").val();

        // Validation

        if(comment == ""){

            $(".error").text(

                "Comment cannot be empty"
            );

            return;
        }

        $(".error").text("");

        // AJAX POST

        $.post(

            "add.php",

            {
                text: comment
            },

            function(data){

                $("#comments").append(

                    "<div class='comment'>"

                    + data +

                    "</div>"
                );

                $(".comment:last").fadeIn();

                $("#msg").val("");
            }

        );

    });

});

</script>

</body>

</html>